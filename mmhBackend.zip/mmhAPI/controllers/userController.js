

let getUserPage=async(req,res)=>{
    res.render("user")
}

export {getUserPage}
